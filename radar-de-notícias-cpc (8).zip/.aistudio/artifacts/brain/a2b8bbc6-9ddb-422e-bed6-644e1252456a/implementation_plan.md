# Radar de Notícias CPC — Monitoramento de Segurança Pública

Sistema minimalista de alta eficiência operacional para monitoramento em tempo real, varredura de notícias policiais e de segurança pública, resumos executivos com IA (Gemini 3.8 Flash), alertas de urgência e geração de boletins diários para WhatsApp sem necessidade de banco de dados.

---

### Decisões Confirmadas e Revisão do Usuário

> [!IMPORTANT]
> O sistema foi projetado estritamente conforme as especificações fornecidas e a confirmação das diretrizes:

- **Escopo e Foco Regional (Confirmado)**: Cobertura configurável para todo o Brasil, com seletores rápidos para Comandos de Policiamento da Capital (ex.: CPC SP - PMESP, CPC RS - Brigada Militar, CPC PR - PMPR, CPC GO - PMGO, CPC RJ, CPC DF) e liberdade para qualquer município ou estado.
- **Varredura e Inteligência (Confirmado)**: Mecanismo híbrido de busca inteligente com Google Search Grounding alimentado por Gemini 3.8 Flash no backend Express (proxy serverless compatível com Vercel), combinando fontes de portais policiais, secretarias de segurança, blogs e redes de notícias com resumos executivos automáticos de alto nível.
- **Compartilhamento WhatsApp (Confirmado)**: Geração de boletins estruturados com formatação nativa para WhatsApp (`*negrito*`, `_itálico_`, tópicos, nível de criticidade e links diretos das fontes originais), com botão de envio direto (`wa.me/?text=...`) e cópia para área de transferência em 1 clique.
- **Zero Banco de Dados (Confirmado)**: Sem necessidade de banco de dados relacional ou NoSQL (baixo custo de manutenção e total portabilidade para Vercel). O estado da aplicação, filtros customizados, histórico local de matérias lidas e boletins do dia são persistidos no `localStorage` do navegador com opção de backup/exportação JSON.

---

### 1. Visão Geral e Conceito Central

- **O que faz**: O **Radar de Notícias CPC** atua como uma central diária de inteligência de fontes abertas (OSINT) e assessoria de comunicação operacional, automatizando a varredura e curadoria de notícias policiais, ocorrências relevantes, tendências criminais e pautas de segurança pública.
- **Público-alvo**: Oficiais e praças das polícias militares e civis, equipes de assessoria de comunicação de comandos (CPC/Secretarias de Segurança), analistas de inteligência, gestores públicos e cidadãos interessados em monitoramento policial confiável.
- **Valor Principal**: Elimina horas de clipping manual diário. Cada matéria é classificada por nível de criticidade (*Normal*, *Atenção*, *Crítico/Urgente*), recebe um resumo executivo gerado por IA com fatos essenciais, destaca a data e o link original, e permite compilar o relatório do dia pronto para despacho no WhatsApp em segundos.

---

### 2. Experiência do Usuário e Design Visual

- **Estética & Visual**:
  - *Identidade*: Minimalismo tático e institucional, transmitindo sobriedade, agilidade e clareza visual de uma central de comando moderna.
  - *Paleta 60-30-10*:
    - 60% Fundo neutro limpo (Dark mode tático: slate profundo `#0B1120` / `#0F172A` e Light mode clean: branco puro e cinza neutro `#F8FAFC`).
    - 30% Superfícies estruturais, divisores ultrafinos (hairline borders de 1px) e tipografia neutra hierarquizada.
    - 10% Acentos funcionais de criticidade: Vermelho Carmim (`#DC2626`) para Alertas Críticos/Urgentes, Âmbar (`#D97706`) para Atenção/Relevante, e Azul Institucional/Esmeralda para status normais e ações primárias.
  - *Tipografia*: Manrope / Plus Jakarta Sans para títulos e seções, DM Sans para corpo de texto com leitura confortável (65-75 caracteres por linha), e algarismos tabulares / JetBrains Mono para datas, horários e carimbos de ocorrência.
  - *Zero-Pill Discipline*: Metadados estruturados com separadores tipográficos limpos (`·`, `/`) sem acúmulo de badges estáticos decorativos.
- **Fluxos Principais**:
  1. **Barra Superior de Comando**: Nome do sistema "Radar de Notícias CPC", seletor rápido de região/Comando CPC, alternador de tema (Claro/Escuro) e botão de ação primária "Gerar Relatório Diário".
  2. **Barra de Filtros Operacionais**: Filtro por data (Hoje, Últimas 24h, Últimos 7 dias, Intervalo customizado), localidade/cidade/estado e palavras-chave específicas (ex.: "tráfico de drogas", "apreensão de fuzil", "operação integrada", "homicídio", "CPC").
  3. **Feed do Radar com Alerta Crítico em Tempo Real**:
     - Notificações de matérias críticas ou urgentes em banner de alta visibilidade com alerta sonoro sutil (opcional e desativável).
     - Cada cartão exibe: Título original, veículo/fonte, data/hora formatada, selo de criticidade legível, resumo executivo gerado por IA (3 a 4 tópicos diretos e objetivos) e botão com link direto para a matéria original.
  4. **Central de Relatório Diário & Compartilhamento WhatsApp**:
     - Modal de compilação automática das notícias selecionadas ou do período filtrado.
     - Resumo executivo consolidado do dia ("Briefing de Inteligência CPC").
     - Prévia formatada para WhatsApp.
     - Botão de envio direto via WhatsApp Web / App (`api.whatsapp.com/send?text=...`) e botão de copiar mensagem.

---

### 3. Decisões de Arquitetura e Solução Técnica

- **Abordagem Sem Banco de Dados**:
  - Execução 100% serverless: O frontend React gerencia a interface e o estado em memória e `localStorage`.
  - O backend Express (`server.ts`) atua como proxy seguro para a API Gemini 3.8 Flash, mantendo a chave `GEMINI_API_KEY` estritamente no servidor.
  - Custo zero de banco de dados, sem provisionamento ou migrações, garantindo que o projeto rode no Vercel ou Cloud Run com baixíssimo custo e manutenção mínima.
- **Inteligência e Busca de Notícias com Gemini 3.8 Flash**:
  - O endpoint `/api/radar/search` utiliza o modelo `gemini-3.8-flash` com `googleSearch: {}` (Search Grounding) para buscar notícias reais e recentes de segurança pública no Brasil conforme os filtros do usuário.
  - O modelo processa as fontes, extrai as URLs reais dos artigos (`groundingMetadata.groundingChunks`), formula o título oficial, veículo jornalístico, data e o resumo executivo operacional em formato JSON estruturado com classificação de urgência (`NORMAL`, `RELEVANTE`, `CRITICO_URGENTE`).
- **Resiliência e Modo Offline/Demonstração**:
  - Inclui uma base com curadoria de ocorrências e pautas reais de referência do CPC para visualização imediata inicial, permitindo testes instantâneos mesmo em caso de latência de rede externa.

---

### 4. Diagrama de Arquitetura e Fluxo de Dados

```
┌────────────────────────────────────────────────────────────────────────┐
│                   Radar de Notícias CPC (Frontend)                     │
│                                                                        │
│  ┌───────────────────────┐  ┌──────────────────────────────────────┐  │
│  │ Filtros Operacionais  │  │ Central de Alertas Críticos (Ao Vivo)│  │
│  │ - Data / Período      │  │ - Badge de Urgência                  │  │
│  │ - Região / Comando CPC│  │ - Aviso visual e sonoro opcional     │  │
│  │ - Palavras-Chave      │  └──────────────────────────────────────┘  │
│  └──────────┬────────────┘                                             │
│             │                                                          │
│             ▼                                                          │
│  ┌──────────────────────────────────────────────────────────────────┐  │
│  │ Feed de Matérias com Resumo Executivo IA                         │  │
│  │ [Título] · [Veículo] · [Data] · [Link Original] · [Resumo IA]    │  │
│  └──────────────────────────┬───────────────────────────────────────┘  │
│                             │                                          │
│                             ▼                                          │
│  ┌──────────────────────────────────────────────────────────────────┐  │
│  │ Gerador de Relatório Diário CPC                                  │  │
│  │ - Síntese executiva do período                                   │  │
│  │ - Compartilhamento direto WhatsApp (wa.me) e Copiar Texto        │  │
│  └──────────────────────────────────────────────────────────────────┘  │
│                             ▲                                          │
│                             │ Estado Local (localStorage)              │
└─────────────────────────────┼──────────────────────────────────────────┘
                              │
                    Chamadas API REST (/api/...)
                              │
┌─────────────────────────────▼──────────────────────────────────────────┐
│                    Backend Serverless (Express)                        │
│                                                                        │
│  ┌──────────────────────────────────────────────────────────────────┐  │
│  │ POST /api/radar/scan (Gemini 3.8 Flash + Google Search Grounding)│  │
│  │ - Varredura de notícias com URLs reais e Grounding Chunks        │  │
│  │ - Síntese executiva operacional em JSON estruturado              │  │
│  │ - Avaliação de severidade e criticidade de segurança pública     │  │
│  └──────────────────────────────────────────────────────────────────┘  │
│  ┌──────────────────────────────────────────────────────────────────┐  │
│  │ POST /api/radar/report (Síntese e Formatação para WhatsApp)      │  │
│  └──────────────────────────────────────────────────────────────────┘  │
└────────────────────────────────────────────────────────────────────────┘
```

---

### 5. Plano de Entrega e Verificação

1. **Configuração de Metadados e Servidor**:
   - Atualizar `metadata.json` com nome oficial "Radar de notícias CPC" e descrição.
   - Configurar `server.ts` com Express e integração com `@google/genai` utilizando `gemini-3.8-flash` e ferramentas de busca.
2. **Componentes e Interface Minimalista**:
   - Layout de comando com paleta institucional, suporte a Dark/Light mode (`@custom-variant dark`).
   - Barra de filtros com busca por palavras-chave, intervalo de datas e comutação rápida de regiões do CPC (ex.: SP, RS, PR, RJ, GO, Geral Brasil).
   - Feed de notícias com cards refinados contendo título, resumo executivo em tópicos claros, data/hora, fonte e link externo verificado.
   - Sistema de alertas em tempo real para ocorrências marcadas como "Crítico/Urgente" com filtro rápido "Apenas Urgentes".
   - Painel do Relatório Diário com geração instantânea do briefing e botão de compartilhamento com a formatação nativa do WhatsApp.
3. **Validação & Compilação**:
   - Verificação completa através de `compile_applet`.
